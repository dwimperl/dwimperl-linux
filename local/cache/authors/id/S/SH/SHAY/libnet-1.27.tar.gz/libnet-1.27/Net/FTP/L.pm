package Net::FTP::L;

require Net::FTP::I;

@ISA = qw(Net::FTP::I);
$VERSION = "0.01";

1;

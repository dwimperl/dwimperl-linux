HV* tagEntry_to_HV (tagEntry* theEntry);


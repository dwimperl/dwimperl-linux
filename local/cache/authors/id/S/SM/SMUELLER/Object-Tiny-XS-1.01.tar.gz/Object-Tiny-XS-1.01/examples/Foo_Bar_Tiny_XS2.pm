package Foo_Bar_Tiny_XS2;

use Object::Tiny::XS qw{ q w e r t y u i o p a s d f g h j k l z x c v b n m q};

1;

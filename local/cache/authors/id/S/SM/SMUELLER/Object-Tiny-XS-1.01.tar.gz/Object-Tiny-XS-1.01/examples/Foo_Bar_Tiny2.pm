package Foo_Bar_Tiny2;

use Object::Tiny qw{ q w e r t y u i o p a s d f g h j k l z x c v b n m q};

1;

package Foo_Bar_Tiny_XS;

use Object::Tiny::XS qw{ foo bar baz };

1;

Please read the guide for [contributing to Mojolicious](http://mojolicio.us/perldoc/Mojolicious/Guides/Contributing), Minion is a spin-off project and follows the same rules.

package WebService::GData::Node::GD::Name;
use WebService::GData::Node::GD;


1;

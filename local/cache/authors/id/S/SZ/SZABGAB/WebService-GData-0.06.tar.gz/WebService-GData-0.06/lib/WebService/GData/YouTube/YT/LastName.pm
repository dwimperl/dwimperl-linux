package WebService::GData::YouTube::YT::LastName;
use WebService::GData::YouTube::YT;

1;
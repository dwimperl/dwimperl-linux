package WebService::GData::Node::Atom::Link;
use WebService::GData::Node::Atom;

set_meta(
    attributes=>[qw(rel type href)],
    is_parent=>0
);

1;

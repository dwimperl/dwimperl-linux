package WebService::GData::Node::GD::Region;
use WebService::GData::Node::GD;


1;

package WebService::GData::YouTube::YT::Location;
use WebService::GData::YouTube::YT;

1;
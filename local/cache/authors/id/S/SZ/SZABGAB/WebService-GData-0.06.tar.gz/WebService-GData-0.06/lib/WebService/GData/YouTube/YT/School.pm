package WebService::GData::YouTube::YT::School;
use WebService::GData::YouTube::YT;


1;
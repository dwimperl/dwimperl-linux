package WebService::GData::Node::GD::FormattedAddress;
use WebService::GData::Node::GD;

1;

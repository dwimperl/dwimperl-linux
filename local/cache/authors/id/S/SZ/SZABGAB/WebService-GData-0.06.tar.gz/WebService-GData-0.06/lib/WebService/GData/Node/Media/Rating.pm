package WebService::GData::Node::Media::Rating;
use WebService::GData::Node::Media;

set_meta(
    attributes=>['scheme','country']
);

1;

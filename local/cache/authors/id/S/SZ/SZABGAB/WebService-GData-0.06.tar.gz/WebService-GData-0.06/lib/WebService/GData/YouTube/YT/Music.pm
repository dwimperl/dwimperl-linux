package WebService::GData::YouTube::YT::Music;
use WebService::GData::YouTube::YT;

1;
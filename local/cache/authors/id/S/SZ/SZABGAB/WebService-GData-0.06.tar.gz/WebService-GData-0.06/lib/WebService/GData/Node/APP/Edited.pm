package WebService::GData::Node::APP::Edited;
use WebService::GData::Node::APP;

1;

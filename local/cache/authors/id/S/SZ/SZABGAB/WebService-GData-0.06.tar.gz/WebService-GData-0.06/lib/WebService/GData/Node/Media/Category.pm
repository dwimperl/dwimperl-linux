package WebService::GData::Node::Media::Category;
use WebService::GData::Node::Media;

set_meta(
    attributes=>['scheme','label']
);

1;

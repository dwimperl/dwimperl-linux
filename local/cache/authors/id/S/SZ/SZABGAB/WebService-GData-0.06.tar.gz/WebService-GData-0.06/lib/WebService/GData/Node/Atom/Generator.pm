package WebService::GData::Node::Atom::Generator;
use WebService::GData::Node::Atom;

set_meta(
    attributes=>[qw(version uri)]
);

1;

package WebService::GData::Node::GD::StructuredPostalAddress;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(rel mailClass usage label primary)]
);

1;

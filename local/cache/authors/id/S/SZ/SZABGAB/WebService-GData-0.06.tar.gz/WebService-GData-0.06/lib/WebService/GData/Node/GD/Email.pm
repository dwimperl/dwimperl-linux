package WebService::GData::Node::GD::Email;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(address displayName label rel primary)]
);

1;

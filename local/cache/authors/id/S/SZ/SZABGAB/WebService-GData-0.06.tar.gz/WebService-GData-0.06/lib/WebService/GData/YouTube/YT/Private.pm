package WebService::GData::YouTube::YT::Private;
use WebService::GData::YouTube::YT;

set_meta(
    is_parent=>0
);

1;
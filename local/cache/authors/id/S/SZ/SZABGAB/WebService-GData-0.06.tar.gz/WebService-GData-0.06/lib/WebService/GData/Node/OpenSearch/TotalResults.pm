package WebService::GData::Node::OpenSearch::TotalResults;
use WebService::GData::Node::OpenSearch;


1;

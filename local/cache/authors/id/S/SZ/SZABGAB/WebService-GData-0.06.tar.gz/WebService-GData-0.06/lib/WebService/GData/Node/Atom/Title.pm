package WebService::GData::Node::Atom::Title;
use WebService::GData::Node::Atom;

set_meta(
    attributes=>[qw(type)]
);
1;

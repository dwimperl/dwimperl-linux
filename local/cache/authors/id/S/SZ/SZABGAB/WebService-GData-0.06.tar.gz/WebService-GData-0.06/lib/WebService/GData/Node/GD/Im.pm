package WebService::GData::Node::GD::Im;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(address label rel protocol primary)],
   is_parent=>0
);

1;

package WebService::GData::YouTube::YT::AccessControl;
use WebService::GData::YouTube::YT;

set_meta(
  attributes=>[qw(action permission)],
  is_parent =>0
);


1;
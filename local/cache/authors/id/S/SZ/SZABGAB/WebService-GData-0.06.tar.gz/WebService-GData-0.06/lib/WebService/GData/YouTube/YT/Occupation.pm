package WebService::GData::YouTube::YT::Occupation;
use WebService::GData::YouTube::YT;

1;
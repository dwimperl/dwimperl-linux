package WebService::GData::Node::Atom::Id;
use WebService::GData::Node::Atom;


1;

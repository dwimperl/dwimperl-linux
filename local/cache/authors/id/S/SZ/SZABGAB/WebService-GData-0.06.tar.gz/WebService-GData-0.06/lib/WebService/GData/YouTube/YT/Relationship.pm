package WebService::GData::YouTube::YT::Relationship;
use WebService::GData::YouTube::YT;


1;
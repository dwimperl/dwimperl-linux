package WebService::GData::Node::Atom::Uri;
use WebService::GData::Node::Atom;


1;

package WebService::GData::Node::GD::OrgJobDescription;
use WebService::GData::Node::GD;


1;

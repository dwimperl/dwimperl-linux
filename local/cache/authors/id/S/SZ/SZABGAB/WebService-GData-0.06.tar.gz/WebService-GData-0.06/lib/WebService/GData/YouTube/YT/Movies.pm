package WebService::GData::YouTube::YT::Movies;
use WebService::GData::YouTube::YT;

1;
package WebService::GData::Node::GD::Housename;
use WebService::GData::Node::GD;


1;

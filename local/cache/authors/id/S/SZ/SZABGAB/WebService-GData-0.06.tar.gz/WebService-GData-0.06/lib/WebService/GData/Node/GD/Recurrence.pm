package WebService::GData::Node::GD::Recurrence;
use WebService::GData::Node::GD;


1;

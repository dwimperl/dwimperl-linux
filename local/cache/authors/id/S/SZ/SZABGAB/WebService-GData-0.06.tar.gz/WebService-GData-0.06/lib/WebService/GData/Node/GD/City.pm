package WebService::GData::Node::GD::City;
use WebService::GData::Node::GD;


1;

package WebService::GData::Node::Atom::Published;
use WebService::GData::Node::Atom;


1;

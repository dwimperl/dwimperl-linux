package WebService::GData::Node::GD::PostalAddress;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(label rel primary)]
);

1;

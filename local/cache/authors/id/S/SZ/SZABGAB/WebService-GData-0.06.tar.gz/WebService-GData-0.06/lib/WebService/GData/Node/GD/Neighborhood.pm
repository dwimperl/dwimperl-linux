package WebService::GData::Node::GD::Neighborhood;
use WebService::GData::Node::GD;


1;

package WebService::GData::Node::GML::Pos;
use WebService::GData::Node::GML;

1;

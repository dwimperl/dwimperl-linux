package WebService::GData::YouTube::YT::AspectRatio;
use WebService::GData::YouTube::YT;


1;
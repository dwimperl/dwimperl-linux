package WebService::GData::YouTube::YT::Duration;
use WebService::GData::YouTube::YT;

set_meta(
  attributes=>[qw(seconds)],
  is_parent =>0
);


1;
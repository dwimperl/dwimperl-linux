package WebService::GData::YouTube::YT::Uploaded;
use WebService::GData::YouTube::YT;

1;
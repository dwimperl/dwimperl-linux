package WebService::GData::Node::Atom::Content;
use WebService::GData::Node::Atom;

set_meta(
    attributes=>[qw(src type)]
);

1;

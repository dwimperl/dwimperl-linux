package WebService::GData::YouTube::YT::Position;
use WebService::GData::YouTube::YT;

1;
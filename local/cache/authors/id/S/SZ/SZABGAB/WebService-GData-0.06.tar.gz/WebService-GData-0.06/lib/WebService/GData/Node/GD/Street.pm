package WebService::GData::Node::GD::Street;
use WebService::GData::Node::GD;


1;

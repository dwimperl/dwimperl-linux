package WebService::GData::YouTube::YT::Status;
use WebService::GData::YouTube::YT;

1;
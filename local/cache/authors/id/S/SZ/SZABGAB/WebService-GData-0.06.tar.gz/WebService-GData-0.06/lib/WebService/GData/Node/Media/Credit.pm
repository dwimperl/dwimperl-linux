package WebService::GData::Node::Media::Credit;
use WebService::GData::Node::Media;

set_meta(
    attributes=>['role','scheme']
);

1;

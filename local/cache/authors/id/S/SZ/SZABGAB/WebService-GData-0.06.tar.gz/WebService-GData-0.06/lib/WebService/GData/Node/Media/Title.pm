package WebService::GData::Node::Media::Title;
use WebService::GData::Node::Media;

set_meta(
    attributes=>[qw(type)]
);

1;

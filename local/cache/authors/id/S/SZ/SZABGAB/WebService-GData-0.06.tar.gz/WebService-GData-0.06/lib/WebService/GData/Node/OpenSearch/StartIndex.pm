package WebService::GData::Node::OpenSearch::StartIndex;
use WebService::GData::Node::OpenSearch;


1;

package WebService::GData::Node::GD::Where;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(label rel valueString)]
);

1;

package WebService::GData::Node::Media::Content;
use WebService::GData::Node::Media;

set_meta(
    attributes=>[qw(url type medium isDefault expression duration)],
    is_parent =>0
);



1;

package WebService::GData::YouTube::YT::Videoid;
use WebService::GData::YouTube::YT;

1;
package WebService::GData::Node::GD::Who;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(email rel valueString)]
);

1;

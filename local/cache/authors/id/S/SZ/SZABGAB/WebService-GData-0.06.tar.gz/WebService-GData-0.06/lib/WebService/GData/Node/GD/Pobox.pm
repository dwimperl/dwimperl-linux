package WebService::GData::Node::GD::Pobox;
use WebService::GData::Node::GD;


1;

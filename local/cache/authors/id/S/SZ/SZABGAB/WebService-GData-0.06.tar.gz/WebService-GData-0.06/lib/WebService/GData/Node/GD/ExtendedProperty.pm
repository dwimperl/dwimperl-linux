package WebService::GData::Node::GD::ExtendedProperty;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(name value)]
);

1;

package WebService::GData::Node::Atom::Summary;
use WebService::GData::Node::Atom;


1;

package WebService::GData::Node::GD::PhoneNumber;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(label rel uri primary)]
);

1;

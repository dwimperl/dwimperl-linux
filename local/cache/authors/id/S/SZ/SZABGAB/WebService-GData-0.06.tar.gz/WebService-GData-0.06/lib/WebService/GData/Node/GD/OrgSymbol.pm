package WebService::GData::Node::GD::OrgSymbol;
use WebService::GData::Node::GD;


1;

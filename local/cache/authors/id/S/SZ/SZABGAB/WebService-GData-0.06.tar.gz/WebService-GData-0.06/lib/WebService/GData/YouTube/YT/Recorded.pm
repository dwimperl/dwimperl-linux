package WebService::GData::YouTube::YT::Recorded;
use WebService::GData::YouTube::YT;


1;
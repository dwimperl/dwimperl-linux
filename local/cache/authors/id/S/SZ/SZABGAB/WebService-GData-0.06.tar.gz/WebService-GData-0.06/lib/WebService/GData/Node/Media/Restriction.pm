package WebService::GData::Node::Media::Restriction;
use WebService::GData::Node::Media;

set_meta(
    attributes=>['type','relationship']
);

1;

package WebService::GData::Node::Atom::Author;
use WebService::GData::Node::Atom;

1;

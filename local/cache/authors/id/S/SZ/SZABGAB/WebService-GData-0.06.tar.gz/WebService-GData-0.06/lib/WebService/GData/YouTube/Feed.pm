package WebService::GData::YouTube::Feed;
use base WebService::GData::Feed;
our $VERSION  = 0.01_01;
1;
package WebService::GData::Node::GD::ResourceId;
use WebService::GData::Node::GD;


1;

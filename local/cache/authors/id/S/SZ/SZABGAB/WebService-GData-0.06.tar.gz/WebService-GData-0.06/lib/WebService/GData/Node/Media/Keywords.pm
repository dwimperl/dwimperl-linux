package WebService::GData::Node::Media::Keywords;
use WebService::GData::Node::Media;


1;

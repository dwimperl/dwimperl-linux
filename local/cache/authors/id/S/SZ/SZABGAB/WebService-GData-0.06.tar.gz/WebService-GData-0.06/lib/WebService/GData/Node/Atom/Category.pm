package WebService::GData::Node::Atom::Category;
use WebService::GData::Node::Atom;

set_meta(
    attributes=>['scheme','term','label'],
    is_parent=>0
);

1;

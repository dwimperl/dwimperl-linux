package WebService::GData::Node::GD::EntryLink;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(href readOnly rel)]
);

1;

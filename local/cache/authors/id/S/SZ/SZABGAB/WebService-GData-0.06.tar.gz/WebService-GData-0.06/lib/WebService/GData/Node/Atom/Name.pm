package WebService::GData::Node::Atom::Name;
use WebService::GData::Node::Atom;


1;

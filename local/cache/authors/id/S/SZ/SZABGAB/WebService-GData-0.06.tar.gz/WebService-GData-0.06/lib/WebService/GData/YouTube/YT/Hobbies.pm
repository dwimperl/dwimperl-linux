package WebService::GData::YouTube::YT::Hobbies;
use WebService::GData::YouTube::YT;


1;
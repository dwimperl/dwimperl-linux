package WebService::GData::Node::GD::Comments;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(rel)]
);

1;

package WebService::GData::Node::OpenSearch::ItemsPerPage;
use WebService::GData::Node::OpenSearch;


1;

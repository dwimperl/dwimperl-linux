package WebService::GData::Node::GD::RecurrenceException;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(specialized)]
);

1;

package WebService::GData::YouTube::YT::CountHint;
use WebService::GData::YouTube::YT;


1;
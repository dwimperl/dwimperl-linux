package WebService::GData::Node::GD::OrgName;
use WebService::GData::Node::GD;

set_meta(
    attributes=>[qw(yomi)]
);


1;

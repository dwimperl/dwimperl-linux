package WebService::GData::Node::GD::OrgDepartment;
use WebService::GData::Node::GD;


1;

package WebService::GData::Node::Media::Description;
use WebService::GData::Node::Media;

set_meta(
    attributes=>['type']
);

1;

package WebService::GData::YouTube::Feed::Favorite;
use base WebService::GData::YouTube::Feed::Video;
our $VERSION  = 0.01_01;


1;
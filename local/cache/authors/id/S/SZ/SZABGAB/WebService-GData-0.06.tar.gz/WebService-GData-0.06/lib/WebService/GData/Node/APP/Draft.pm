package WebService::GData::Node::APP::Draft;
use WebService::GData::Node::APP;

1;

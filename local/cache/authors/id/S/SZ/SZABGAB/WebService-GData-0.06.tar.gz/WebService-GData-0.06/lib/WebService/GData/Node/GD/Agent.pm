package WebService::GData::Node::GD::Agent;
use WebService::GData::Node::GD;


1;

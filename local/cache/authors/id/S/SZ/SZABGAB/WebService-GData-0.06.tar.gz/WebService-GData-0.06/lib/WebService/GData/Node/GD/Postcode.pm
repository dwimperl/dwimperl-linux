package WebService::GData::Node::GD::Postcode;
use WebService::GData::Node::GD;


1;

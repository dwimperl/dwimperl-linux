package WebService::GData::Node::GD::OriginalEvent;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(id href)]
);

1;

package WebService::GData::Node::GD::FamilyName;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(yomi)]
);

1;

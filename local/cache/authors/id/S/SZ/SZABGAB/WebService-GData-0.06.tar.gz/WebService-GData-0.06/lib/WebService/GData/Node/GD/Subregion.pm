package WebService::GData::Node::GD::Subregion;
use WebService::GData::Node::GD;


1;

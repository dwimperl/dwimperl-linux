package WebService::GData::Node::APP::Control;
use WebService::GData::Node::APP;

1;

package WebService::GData::Node::GeoRSS::Where;
use WebService::GData::Node::GeoRSS;

1;

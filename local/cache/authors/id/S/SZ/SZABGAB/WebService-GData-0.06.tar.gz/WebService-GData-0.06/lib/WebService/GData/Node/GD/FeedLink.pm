package WebService::GData::Node::GD::FeedLink;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(rel href countHint readOnly)],
   is_parent=>0
);

1;

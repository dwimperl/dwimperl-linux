package WebService::GData::Node::GD::OrgTitle;
use WebService::GData::Node::GD;


1;

package WebService::GData::Node::Media::Group;
use WebService::GData::Node::Media;


1;

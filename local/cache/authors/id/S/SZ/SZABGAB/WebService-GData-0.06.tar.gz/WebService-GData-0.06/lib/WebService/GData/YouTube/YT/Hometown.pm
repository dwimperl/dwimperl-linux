package WebService::GData::YouTube::YT::Hometown;
use WebService::GData::YouTube::YT;


1;
package WebService::GData::Node::GD::Transparency;
use WebService::GData::Node::GD;

set_meta(
    attributes=>[qw(value)],
    is_parent=>0
);


1;

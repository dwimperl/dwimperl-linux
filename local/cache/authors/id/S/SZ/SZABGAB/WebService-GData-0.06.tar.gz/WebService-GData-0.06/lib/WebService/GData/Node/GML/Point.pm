package WebService::GData::Node::GML::Point;
use WebService::GData::Node::GML;

set_meta(
  node_name=>'Point'
); 



1;

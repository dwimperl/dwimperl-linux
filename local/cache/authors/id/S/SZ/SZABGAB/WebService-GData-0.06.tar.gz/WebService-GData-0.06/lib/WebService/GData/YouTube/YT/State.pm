package WebService::GData::YouTube::YT::State;
use WebService::GData::YouTube::YT;

set_meta(
  attributes=>[qw(name reasonCode helpUrl)]
);


1;
package WebService::GData::Node::GD::Organization;
use WebService::GData::Node::GD;

set_meta(
   attributes=>[qw(label primary rel)]
);

1;

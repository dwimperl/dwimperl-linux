package WebService::GData::Node::Media::Player;
use WebService::GData::Node::Media;

set_meta(
    attributes=>['url'],
    is_parent=>0
);

1;

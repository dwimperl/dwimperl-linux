use Class::Accessor 'antlers';

has first => ( is => 'rw' );
has ;#comment
has second => ( is => 'ro' );
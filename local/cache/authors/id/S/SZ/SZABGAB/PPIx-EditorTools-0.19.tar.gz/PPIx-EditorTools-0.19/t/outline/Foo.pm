package Foo;

use Method::Signatures;

method new (%data) {
}

func hello($name, $daytime) {
}

1;


use strict; use warnings;
use Abc;

my $global = 42;

sub qwer {
}


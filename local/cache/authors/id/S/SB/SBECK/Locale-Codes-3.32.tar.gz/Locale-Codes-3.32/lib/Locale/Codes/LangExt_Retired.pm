package #
Locale::Codes::LangExt_Retired;

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'deprecate_codes' is run.
#    Generated on: Tue Aug 26 11:38:09 EDT 2014

use strict;
require 5.006;
use warnings;
use utf8;

our($VERSION);
$VERSION='3.32';

$Locale::Codes::Retired{'langext'}{'alpha'}{'code'} = {
};

$Locale::Codes::Retired{'langext'}{'alpha'}{'name'} = {
   q(hawai'i pidgin sign language) => [ q(hps), q(Hawai'i Pidgin Sign Language) ],
};


1;

package t::Test;

sub run {
    ::ok 1;
}

1;

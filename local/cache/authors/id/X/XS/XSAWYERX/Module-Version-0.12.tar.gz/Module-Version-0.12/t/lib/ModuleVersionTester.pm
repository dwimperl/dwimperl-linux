package ModuleVersionTester;

our $VERSION = '0.01_01';

1;


package FooBarBaz;
BEGIN {
	our $VERSION = 'v9223372036854775807';
}
1;

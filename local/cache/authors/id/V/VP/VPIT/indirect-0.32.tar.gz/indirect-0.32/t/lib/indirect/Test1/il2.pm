package indirect::Test1::il2;
import indirect::Test1::il2;
1;

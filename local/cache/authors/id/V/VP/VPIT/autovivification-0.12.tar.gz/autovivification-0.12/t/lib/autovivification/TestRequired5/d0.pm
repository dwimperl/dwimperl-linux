package autovivification::TestRequired5::d0;
my $x;
my $y = $x->{foo};
1;

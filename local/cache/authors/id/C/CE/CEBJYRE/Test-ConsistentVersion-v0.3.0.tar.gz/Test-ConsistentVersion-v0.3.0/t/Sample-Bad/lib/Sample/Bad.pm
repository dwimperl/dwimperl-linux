package Sample::Bad;

use warnings;
use strict;

use version; our $VERSION = qv('1.2.31');

1;

__END__

=head1 NAME

Sample::Bad - Sample module for testing Test::ConsistentVersion.


=head1 VERSION

1.2.30

=cut


package Sample::vGood;

use warnings;
use strict;

use version; our $VERSION = qv('1.2.31');

1;

__END__

=head1 NAME

Sample::vGood - Sample module for testing Test::ConsistentVersion.


=head1 VERSION

v1.2.31

=cut


package HTMLFormFu::MyModel;

use base 'HTML::FormFu::Model';

1;

package HTMLFormFu::RegressLocalization::en;
use base qw( HTMLFormFu::RegressLocalization );

our %Lexicon = ( foobar => "Foo blah Baz", );

1;

package TestNamespaceSep;
use warnings;
use strict;

use Any::Moose 'X::Types' => [-declare => [qw( Foo::Bar )]];

1;

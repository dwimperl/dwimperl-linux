package # Hide from PAUSE
    TestApp::View::Email::AppConfig;

use Email::Sender::Simple;

use base 'Catalyst::View::Email';

1;

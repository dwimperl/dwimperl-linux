package # Hide from PAUSE
    TestApp::View::Email::Template::AppConfig;

use Email::Sender::Simple;

use base 'Catalyst::View::Email::Template';

1;

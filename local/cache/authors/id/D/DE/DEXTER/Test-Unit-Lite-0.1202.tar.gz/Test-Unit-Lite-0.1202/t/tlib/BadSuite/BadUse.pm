package BadSuite::BadUse;

eval q{

    use TestSuite::NonExistent;

};

1;

package NoTestCaseClassTest;
use strict;
use warnings;

sub new {
}

sub testSuccess {
}

1;

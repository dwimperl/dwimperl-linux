package BadSuite::SyntaxError;

eval q{

    sub broken_method {
        my $self =
    }

};

1;

package BadSuite::SyntaxError;

our $VERSION = 0.01;

our @INC = ('Exception::Base');

1;

package Exception::BaseTest::PurePackage;

our $VERSION = 0.02;
our @ISA = ('Exception::Base');

1;

use strict;
use warnings;

package InsideOut::BaseIO;

use MooseX::InsideOut;

has base_foo => (
  is => 'rw',
);

1;

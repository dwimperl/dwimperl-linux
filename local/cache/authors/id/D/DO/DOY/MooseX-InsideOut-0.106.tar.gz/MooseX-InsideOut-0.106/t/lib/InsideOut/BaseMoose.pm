use strict;
use warnings;

package InsideOut::BaseMoose;

use Moose;

has base_foo => ( is => 'rw' );

1;

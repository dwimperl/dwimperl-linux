package UnderscoreRole;
use Moo::Role;
use ClobberUnderscore;
sub r1 { 'r1' };
1;

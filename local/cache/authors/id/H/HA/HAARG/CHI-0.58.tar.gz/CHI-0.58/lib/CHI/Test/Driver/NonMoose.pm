package CHI::Test::Driver::NonMoose;
{
  $CHI::Test::Driver::NonMoose::VERSION = '0.58';
}
use Carp;
use strict;
use warnings;
use base qw(CHI::Driver::Memory);

1;

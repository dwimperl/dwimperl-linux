package Baz;

use Role::Tiny;

sub baz { 1 }

1;

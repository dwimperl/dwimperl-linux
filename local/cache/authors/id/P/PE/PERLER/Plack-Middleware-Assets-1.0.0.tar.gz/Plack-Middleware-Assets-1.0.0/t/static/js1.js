function() {
    foo
};
(function(w) {
  w.console.log('b');
}(window));

package Code::TidyAll::Test::Class;
$Code::TidyAll::Test::Class::VERSION = '0.20';
use Test::Class::Most;
use strict;
use warnings;

__PACKAGE__->SKIP_CLASS("abstract base class");

1;

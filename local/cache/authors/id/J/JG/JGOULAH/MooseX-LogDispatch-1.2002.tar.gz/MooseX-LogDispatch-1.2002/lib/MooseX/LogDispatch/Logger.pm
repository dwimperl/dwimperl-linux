package # hide from pause
    MooseX::LogDispatch::Logger;
    
use Carp;

sub Logger {
    confess "with Logger() syntax is deprecated and has been removed as of version 1.200. See MooseX::LogDispatch POD for details";
}
1;
# Host Database
#
127.0.0.1   localhost
255.255.255.255   broadcasthost
::1             localhost

192.168.2.23   mango.rexify.org  mango
192.168.2.222 syrr.rexify.org syrr

#
# (c) Jan Gehring <jan.gehring@gmail.com>
#
# vim: set ts=2 sw=2 tw=0:
# vim: set expandtab:

package Rex::Interface::Fs;
{
  $Rex::Interface::Fs::VERSION = '0.53.1';
}

use strict;
use warnings;

use Rex;
use Data::Dumper;

sub create {
  my ( $class, $type ) = @_;

  unless ($type) {

    #$type = Rex::Commands::task()->get_connection_type;
    $type = Rex::get_current_connection()->{conn}
      ->get_connection_type;    #Rex::Commands::task()->get_connection_type;
                                #if(Rex::is_ssh() && ! Rex::is_sudo()) {
                                #  $type = "SSH";
                                #}
                                #elsif(Rex::is_sudo()) {
                                #  $type = "Sudo";
                                #}
                                #else {
                                #  $type = "Local";
                                #}
  }

  my $class_name = "Rex::Interface::Fs::$type";
  eval "use $class_name;";
  if ($@) { die("Error loading Fs interface $type.\n$@"); }

  return $class_name->new;
}

1;

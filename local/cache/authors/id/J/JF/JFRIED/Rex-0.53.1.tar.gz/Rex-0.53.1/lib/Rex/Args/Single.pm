#
# (c) Jan Gehring <jan.gehring@gmail.com>
#
# vim: set ts=2 sw=2 tw=0:
# vim: set expandtab:

package Rex::Args::Single;
{
  $Rex::Args::Single::VERSION = '0.53.1';
}

use strict;
use warnings;

sub get { return 1; }

1;

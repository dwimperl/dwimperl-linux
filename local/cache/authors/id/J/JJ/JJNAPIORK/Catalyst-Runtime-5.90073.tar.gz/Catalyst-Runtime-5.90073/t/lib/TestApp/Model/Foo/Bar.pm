package TestApp::Model::Foo::Bar;

sub model_foo_bar_method_from_foo_bar { "model_foo_bar_method_from_foo_bar" }

1;

#!/usr/local/bin/perl
print "1..3\n";
print "ok\n";
print "not ok\n";
print "ok\n";

package SessionStoreTest2::Model::Session;
use base qw/SessionStoreTest2::Model::Session/;
use strict;
use warnings;

our $VERSION = 0.0001; # Otherwise we get warnings as our package looks empty.

1;


package SessionStoreTest::Model::Session;
use base qw/Catalyst::Model/;
use strict;
use warnings;

# This is currently just a stub!
# t/basic.t implements a closure which gets the model but does nothing with it.
# Tests without a closure should be added.

our $VERSION = 0.0001; # Otherwise we get warnings as our package looks empty.

1;


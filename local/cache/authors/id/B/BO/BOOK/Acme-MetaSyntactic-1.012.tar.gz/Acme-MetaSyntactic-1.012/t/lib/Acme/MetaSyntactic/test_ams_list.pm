package Acme::MetaSyntactic::test_ams_list;
use strict;
use Acme::MetaSyntactic::List;
our @ISA = qw( Acme::MetaSyntactic::List );
__PACKAGE__->init();
1;

__DATA__
# names
John Paul George Ringo

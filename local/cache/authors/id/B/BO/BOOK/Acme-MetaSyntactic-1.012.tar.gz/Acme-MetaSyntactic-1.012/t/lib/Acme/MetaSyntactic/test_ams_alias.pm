package Acme::MetaSyntactic::test_ams_alias;
use Acme::MetaSyntactic::Alias;
our @ISA = qw( Acme::MetaSyntactic::Alias );
__PACKAGE__->init('test_ams_locale');
1;


package TestSchema::ResultSet::Station;
use strict;
use warnings;

# intentionally not using TestSchema::ResultSet
use parent 'DBIx::Class::ResultSet';

1;

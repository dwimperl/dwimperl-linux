package egg;

use chicken;

1;
__END__
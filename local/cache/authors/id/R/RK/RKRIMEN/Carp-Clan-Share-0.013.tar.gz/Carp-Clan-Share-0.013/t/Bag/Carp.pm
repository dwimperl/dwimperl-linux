package t::Bag::Carp;

use strict;
use warnings;

use Carp::Clan::Share;

1;

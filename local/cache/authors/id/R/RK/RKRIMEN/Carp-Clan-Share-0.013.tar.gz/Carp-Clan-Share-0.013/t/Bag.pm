package t::Bag;

use strict;
use warnings;

use t::Bag::A;
use t::Bag::B;

1;

package t::Pack;

use strict;
use warnings;

use Carp::Clan::Share @main::Share;

use t::Pack::A;
use t::Pack::B;

1;

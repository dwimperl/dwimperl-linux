package StashTest;
# ABSTRACT: turns baubles into trinkets
1;

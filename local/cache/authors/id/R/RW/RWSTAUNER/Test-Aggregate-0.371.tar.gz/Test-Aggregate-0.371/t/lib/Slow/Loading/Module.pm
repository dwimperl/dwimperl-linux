package Slow::Loading::Module;

sleep 1;

1;

create table foo (
    id integer not null
);

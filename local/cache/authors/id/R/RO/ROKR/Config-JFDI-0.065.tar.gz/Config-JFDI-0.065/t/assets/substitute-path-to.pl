{   
    default => '__HOME__',
    template => '__path_to(root/template)__',
}


package t::Test;

use strict;
use warnings;

1;

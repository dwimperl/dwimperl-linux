package Config::JFDI::Carp;

use strict;
use warnings;

use Carp::Clan::Share;

1;

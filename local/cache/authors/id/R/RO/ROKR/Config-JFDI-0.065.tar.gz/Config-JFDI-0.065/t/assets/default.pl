{   
    path_to => '__path_to(tatooine)__',
    test => 'beta',
}

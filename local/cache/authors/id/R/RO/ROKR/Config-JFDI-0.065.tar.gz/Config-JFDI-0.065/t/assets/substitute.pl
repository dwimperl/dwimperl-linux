{   
    home => 'a-galaxy-far-far-away',
    default => '__HOME__',
    default_override => '__literal(this)__',
    original => '__two_plus_two__',
    original_embed => '2 + 2 = __two_plus_two__',
    template => '__path_to(root/template)__',
}

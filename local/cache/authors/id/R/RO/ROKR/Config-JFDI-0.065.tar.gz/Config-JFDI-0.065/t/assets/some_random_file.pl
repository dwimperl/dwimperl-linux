{   name              => 'TestApp',
    view              => 'View::TT',
    'Controller::Foo' => { foo => 'bar' },
    'Model::Baz'      => { qux => 'xyzzy' },
    random            => 1,
}

{   view              => 'View::TT::New',
    'Controller::Foo' => { new => 'key' },
    'Model::Baz' => { 'another' => 'new key' },
}

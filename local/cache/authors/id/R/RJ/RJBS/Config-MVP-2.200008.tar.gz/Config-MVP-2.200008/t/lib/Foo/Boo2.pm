package Foo::Boo2;
1;

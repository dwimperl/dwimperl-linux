package Foo::Quux;
1;

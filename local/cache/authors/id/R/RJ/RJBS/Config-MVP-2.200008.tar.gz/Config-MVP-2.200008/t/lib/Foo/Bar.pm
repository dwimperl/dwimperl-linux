package Foo::Bar;
sub mvp_multivalue_args { qw(y) }
1;

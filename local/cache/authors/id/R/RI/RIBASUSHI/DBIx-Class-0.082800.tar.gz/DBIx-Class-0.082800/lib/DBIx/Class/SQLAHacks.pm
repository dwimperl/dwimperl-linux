package # Hide from PAUSE
  DBIx::Class::SQLAHacks;

use warnings;
use strict;

use base qw/DBIx::Class::SQLMaker/;

1;

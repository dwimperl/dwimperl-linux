package DBICNSTest::RtBug41083::ResultSet;
use strict;
use warnings;
use base 'DBIx::Class::ResultSet';
1;

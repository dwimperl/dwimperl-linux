package # Hide from PAUSE
  DBIx::Class::SQLAHacks::MySQL;

use warnings;
use strict;

use base qw( DBIx::Class::SQLMaker::MySQL );

1;

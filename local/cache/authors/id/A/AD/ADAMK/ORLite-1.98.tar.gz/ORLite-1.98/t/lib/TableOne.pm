package t::lib::TableOne;

use strict;

our $VERSION = '1.98';

sub dummy {
	return 2;
}

1;

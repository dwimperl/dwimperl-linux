create table tableOne (
	columnID integer not null primary key,
	ColumnTwo string
);

create table foo (
	foo_id integer not null primary key,
	name string
)

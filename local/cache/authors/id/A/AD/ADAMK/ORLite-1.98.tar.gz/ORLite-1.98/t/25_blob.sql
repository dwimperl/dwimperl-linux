create table foo (
    id integer not null primary key,
    name text not null,
    content Blob not null,
    notype not null
);

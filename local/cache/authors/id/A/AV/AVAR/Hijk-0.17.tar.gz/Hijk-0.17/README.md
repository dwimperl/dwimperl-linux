Hijk
====

Specialized HTTP Client

[![Tavis-CI Build Status](https://travis-ci.org/gugod/Hijk.png?branch=master)](https://travis-ci.org/gugod/Hijk)

[![Coverage Status](https://coveralls.io/repos/gugod/Hijk/badge.png?branch=master)](https://coveralls.io/r/gugod/Hijk?branch=master)

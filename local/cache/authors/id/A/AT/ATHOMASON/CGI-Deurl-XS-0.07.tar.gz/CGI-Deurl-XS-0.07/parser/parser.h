#ifndef _PARSER_H
#define _PARSER_H

#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"

SV* _split_to_parms(char*);

#endif /* _PARSER_H */

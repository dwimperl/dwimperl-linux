package App::Netdisco::Util::Noop;

use strict;
use warnings;

# used for testing library access.

1;

BEGIN;

ALTER TABLE node_wireless DROP CONSTRAINT node_wireless_pkey;

COMMIT;

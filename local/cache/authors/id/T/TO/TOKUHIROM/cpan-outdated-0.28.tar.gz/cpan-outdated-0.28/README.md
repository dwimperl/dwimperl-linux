# NAME

App::cpanoutdated - detect outdated CPAN modules in your environment.

# DESCRIPTION

see [cpan-outdated](http://search.cpan.org/perldoc?cpan-outdated).

# AUTHOR

Tokuhiro Matsuno

# LICENSE

Copyright (C) 2009 Tokuhiro Matsuno.

This library is free software; you can redistribute it and/or modify it under the same terms as Perl itself.

# SEE ALSO

[CPAN](http://search.cpan.org/perldoc?CPAN)

[App::cpanminus](http://search.cpan.org/perldoc?App::cpanminus)

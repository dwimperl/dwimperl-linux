package Pinto::Module::Build;

use strict;
use warnings;

use base 'Module::Build::CleanInstall';

#------------------------------------------------------------------------------
1;

__END__

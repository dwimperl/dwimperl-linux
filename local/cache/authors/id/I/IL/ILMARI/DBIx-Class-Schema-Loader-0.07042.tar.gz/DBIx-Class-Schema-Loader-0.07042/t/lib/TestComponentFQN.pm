package TestComponentFQN;

sub testcomponent_fqn { 'TestComponentFQN works' }

1;

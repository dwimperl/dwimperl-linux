package DBICTest::Schema::_skip_load_external::Foo;
our $skip_me = "bad mojo";
1;

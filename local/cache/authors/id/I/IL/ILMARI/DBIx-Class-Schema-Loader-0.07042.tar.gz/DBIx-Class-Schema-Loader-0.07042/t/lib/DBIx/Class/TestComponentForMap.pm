package DBIx::Class::TestComponentForMap;

sub dbix_class_testcomponentmap { 'dbix_class_testcomponentmap works' }

1;

package TestSchemaComponentFQN;

sub testschemacomponent_fqn { 'TestSchemaComponentFQN works' }

1;

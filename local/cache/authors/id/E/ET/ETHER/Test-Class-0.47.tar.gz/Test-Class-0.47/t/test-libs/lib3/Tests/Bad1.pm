package Tests::Bad1;

use strict;
use warnings;

sub ok { __PACKAGE__ }

1;

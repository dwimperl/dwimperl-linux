use MooseX::Declare;

class dongs
{
}

class mtfnpy extends dongs
{
}

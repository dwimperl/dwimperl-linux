use MooseX::Declare;

class Affe {
    use Tiger;
}

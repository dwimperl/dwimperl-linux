package ClassWithCombiningRole;

use Moose;
use namespace::autoclean;

with 'CombiningRole';

1;

package OtherRole;

use Moose::Role;
use namespace::autoclean;

with 'Role';

1;

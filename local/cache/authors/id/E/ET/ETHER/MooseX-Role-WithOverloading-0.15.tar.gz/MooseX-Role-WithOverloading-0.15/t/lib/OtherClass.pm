package OtherClass;

use Moose;
use namespace::autoclean;

with 'OtherRole';

1;

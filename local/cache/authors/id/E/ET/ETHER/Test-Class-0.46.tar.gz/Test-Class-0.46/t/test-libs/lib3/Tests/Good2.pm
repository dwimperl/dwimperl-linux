package Tests::Good2;

use strict;
use warnings;

sub ok { __PACKAGE__ }

1;

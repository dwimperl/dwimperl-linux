package TestApp3::Plugin::Lives;

use Moose::Role;

use warnings;
use strict;

sub bar {}

1;

package TestApp3::Plugin::Dies1;

use Moose::Role;
die 'oh noes';

1;

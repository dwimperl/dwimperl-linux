package TestApp2;

use strict;
use warnings;
use Moose;

extends 'TestApp';


1;

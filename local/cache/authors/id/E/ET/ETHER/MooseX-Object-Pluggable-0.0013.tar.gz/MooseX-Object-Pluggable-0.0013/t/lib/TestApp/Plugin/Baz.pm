package TestApp::Plugin::Baz;

use strict;
use warnings;
use Moose::Role;

sub baz { 'plugin baz' }

1;

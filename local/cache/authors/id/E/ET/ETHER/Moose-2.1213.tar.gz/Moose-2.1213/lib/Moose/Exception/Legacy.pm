package Moose::Exception::Legacy;
$Moose::Exception::Legacy::VERSION = '2.1213';
use Moose;
extends 'Moose::Exception';

1;

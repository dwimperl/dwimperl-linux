#!perl

use Devel::REPL::Script;
Devel::REPL::Script->import('run');    # should be called 'run'

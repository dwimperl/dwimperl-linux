=head1 BOGUS

Foo.

=cut

package TestAttributeHelpers_Consumer;
use Moose;

with 'TestAttributeHelpers';

sub bar { }

1;

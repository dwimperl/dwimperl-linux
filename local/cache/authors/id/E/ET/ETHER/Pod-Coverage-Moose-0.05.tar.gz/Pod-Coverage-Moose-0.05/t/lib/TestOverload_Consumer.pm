=head1 BOGUS

Foo.

=cut

package TestOverload_Consumer;
use Moose;

with 'TestOverload';

sub bar { }

1;
